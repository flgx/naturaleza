<?php

class Usuario extends Eloquent {

	protected $table = 'users';
	public $timestamps = false;

}
