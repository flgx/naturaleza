<?php

use Backoffice\Entities\Role;

class RoleTableSeeder extends Seeder {

	public function run()
	{

	}

}