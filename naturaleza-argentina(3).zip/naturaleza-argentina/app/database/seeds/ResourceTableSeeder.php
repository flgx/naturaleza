<?php

use Backoffice\Entities\Resource;

class ResourceTableSeeder extends Seeder {

	public function run()
	{

	}

}