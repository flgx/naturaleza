<?php

use Backoffice\Entities\BadWord;

class BadWordTableSeeder extends Seeder {

	public function run()
	{
	
	}

}