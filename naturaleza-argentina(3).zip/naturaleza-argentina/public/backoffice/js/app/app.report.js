'use strict';

$(document).ready(function() {


	$('#datepicker-container .input-daterange').datepicker({
	    format: "dd/mm/yy",
	    language: "es"
	});
});